(c) 2006 Ch. Klippel
this software is gpl'ed software, read the file "LICENSE.txt" for details

transistor bass emulation
