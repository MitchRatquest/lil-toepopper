LADSPA and VST plug-in hosting for Pd

This is a Pd tilde object for hosting LADSPA audio plug-ins. The
LADSPA plug-in interface is supported completely. The object will
search your LADSPA path for plugins, which are loadable by name as an
argument to the plugin~ object.

Jarno Sepp�nen, jams@cs.tut.fi

