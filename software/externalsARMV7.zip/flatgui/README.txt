
flatgui is a library of GUI objects that were part of the old
'flatspace' collection that was discontinued.  
