SHARE_MEM
version 1. - nov 2012
cyrille henry - nicolas montgermont

INFOS
share_mem allows the usage of shared memory in Pd.

BUILD & INSTALL
Just do make and sudo make install.
If you don't want to build yourself, you may find binaries updated everynight here:
https://macosx105-i386.pdlab.puredata.info/job/template-libraries/