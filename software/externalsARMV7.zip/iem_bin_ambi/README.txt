This library extends the performance of miller puckette's pure data (pd).

iem_bin_ambi contains 2 objects: 
"bin_ambi_reduced_decode_fft2" and "bin_ambi_reduced_decode_fir2" 
which calculate the product of an ambisonic decoder-matrix and the binaural HRIR's. 
(in frequency and in time domain)
